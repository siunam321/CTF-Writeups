<?php
/**
 * Templates Customizer Section.
 *
 * @package Login Customizer
 */

// Return early if the class is missing.
if ( ! class_exists( 'Login_Customizer_Templates' ) ) {
	return;
}

// Set template choices.
$login_customizer_template = new Login_Customizer_Templates();

$wp_customize->add_setting(
	'login_customizer[template]',
	array(
		'default'   => 'default',
		'type'      => 'option',
		'transport' => 'postMessage',
	)
);

$wp_customize->add_control(
	new Login_Customizer_Template_Control(
		$wp_customize,
		'login_customizer[template]',
		array(
			'type'    => 'login-customizer-templates',
			'section' => 'login_customizer__section--templates',
			'choices' => $this->get_choices( $login_customizer_template->get_templates() ),
		)
	)
);
