#!/bin/bash
set -e
while true; do timeout 600 python3 /app/app.py ; done