<?php
class PatchstackSchedulerAnalytics {
    private $stats = array();
    
    public function track_view($post_id) {
        if (!isset($this->stats[$post_id])) {
            $this->stats[$post_id] = 0;
        }
        $this->stats[$post_id]++;
    }
    
    public function get_popular_posts() {
        arsort($this->stats);
        return array_slice($this->stats, 0, 5, true);
    }
} 