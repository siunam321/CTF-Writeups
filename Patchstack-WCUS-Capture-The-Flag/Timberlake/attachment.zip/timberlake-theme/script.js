// Vanta.js Background Effect
VANTA.GLOBE({
    el: "#vanta-bg",
    mouseControls: true,  // Disable mouse control
    touchControls: true,  // Disable touch control
    gyroControls: false,   // Disable gyro control
    minHeight: 200.00,
    minWidth: 200.00,
    scale: 1.00,
    scaleMobile: 1.00,
    color: 0x00ff00,
    color2: 0x000000,
    backgroundColor: 0x000000
  });
  
  // GSAP Animations
  gsap.to(".gandalf-image", 
      { rotate: 360, duration: 5, ease: "linear", repeat: -1 } // Faster rotation (5 seconds)
  );
  
  gsap.to(".gandalf-container", 
      { opacity: 0.7, duration: 2, yoyo: true, repeat: -1, ease: "power1.inOut" }
  );