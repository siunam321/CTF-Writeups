#!/bin/sh

yarn db:deploy && node app.js