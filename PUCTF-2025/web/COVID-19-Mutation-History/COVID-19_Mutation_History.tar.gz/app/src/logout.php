<?php
require_once "helper/constant.php";
require_once "helper/utils.php";

validateSession();
logout();