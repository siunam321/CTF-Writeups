SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

CREATE DATABASE IF NOT EXISTS `firebird_chan_fanclub_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `firebird_chan_fanclub_db`;

CREATE TABLE `users` (
    `UserId` INT NOT NULL AUTO_INCREMENT,
    `Username` VARCHAR(255) NOT NULL,
    `Password` TEXT NOT NULL,
    `Role` ENUM('Guest', 'Member') NOT NULL DEFAULT 'Member',
    PRIMARY KEY (UserId),
    UNIQUE (Username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `scores` (
    `Username` varchar(255) NOT NULL,
    `Score` INT NOT NULL,
    `Role` ENUM('Guest', 'Member') NOT NULL DEFAULT 'Member',
    PRIMARY KEY (Username),
    UNIQUE (Username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Time to set a very secure password! - Firebird Chan
INSERT INTO `users` (Username, Password, Role) VALUES ('Firebird Chan', "123", "Member");
INSERT INTO `scores` (Username, Score, Role) VALUES ('Firebird Chan', 5, "Member");

CREATE USER IF NOT EXISTS 'challenge'@'%' IDENTIFIED BY 'REDACTED';
GRANT SELECT, INSERT, UPDATE ON firebird_chan_fanclub_db.* TO 'challenge'@'%';
FLUSH PRIVILEGES;