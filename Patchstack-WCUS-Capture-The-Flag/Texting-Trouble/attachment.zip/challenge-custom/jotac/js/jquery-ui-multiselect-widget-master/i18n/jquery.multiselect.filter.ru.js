/* Russian initialisation for the jQuery UI multiselect plugin. */
/* Written by Artem Packhomov (gorblnu4@gmail.com). */

(function ( $ ) {

$.extend($.ech.multiselectfilter.prototype.options, {
	label: "Фильтр:",
	placeholder: "Введите запрос"
});

})( jQuery );
