<h1 class="kiwi_title">Kiwiblocks</h1>

<div class="kiwi_panel">

    <?php
		try
		{
			@include_once __DIR__ . '/menu.php';
		}
		catch(Throwable $e)
		{
			error_log("Error loading menu: " . $e->getMessage());
		}

        $tab = isset($_GET['tab']) ? $_GET['tab'] : 'general.php';
		try
		{
			@include_once __DIR__ . '/tabs/' . $tab;
		}
		catch(Throwable $e)
		{
			error_log("Error loading tab: " . $e->getMessage());
		}
        
    ?>

</div>
