<?php
session_start();
date_default_timezone_set("Asia/Hong_Kong");
error_reporting(0);

$flag = getenv("FLAG");

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] === false) {
    session_destroy();
    header("Location: /login.php");
    die();
}

if (!isset($_SESSION['role']) || $_SESSION['role'] !== "Member") {
    $flag = "You are not a member.";
}

?>

<!DOCTYPE html>
<html>

<head>
    <style>
    <?php include 'style.css';
    ?>
    </style>
    <title>Home - Firebird Chan's Fanclub</title>
</head>

<body>
    <div class="container hero is-fullheight">

        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="/register.php">
                        Register
                    </a>
                    <a class="navbar-item" href="/login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="/play.php">
                        Play
                    </a>
                    <a class="navbar-item" href="/leaderboard.php">
                        Leaderboard
                    </a>
                    <a class="navbar-item" href="/flag.php">
                        Flag (For Members Only)
                    </a>
                    <a class="navbar-item" href="/logout.php">
                        Logout
                    </a>
                </div>

                <div class="navbar-end">
                    <div class="navbar-item">
                        <div class="buttons">
                            <a class="button is-primary" href="https://www.youtube.com/watch?v=Gc5NIjuAmU4&list=PLuxqoToY7UciHpW1-lDtgThiW4UbbyQ4_">
                                Hi, <?php echo $_SESSION['username'];?>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </nav>

        <div class="hero-body">
            <div class="container">
                <section class="hero is-success is-halfheight">
                    <div class="hero-body">
                        <div class="container has-text-centered">
                            <p class="title"><?php echo $flag; ?></p>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        <footer class="has-text-centered mt-auto pt-5 pb-5">
            <p>Styled with <a href="https://bulma.io/">Bulma</a>. </p>
        </footer>

    </div>

</body>

</html>