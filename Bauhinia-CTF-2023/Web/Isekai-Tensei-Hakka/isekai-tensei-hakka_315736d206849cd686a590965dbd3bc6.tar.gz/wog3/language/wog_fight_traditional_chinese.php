<?
/*===================================================== 
 Copyright (C) ETERNAL<iqstar.tw@gmail.com>
 Modify : 2005/01/29
 URL : http://www.2233.idv.tw
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
===================================================== */


$lang['wog_fight_no_hp'] = 'HP為0 請好好休息再來挑戰';
$lang['wog_fight_select_area'] = '請重新選擇場地';
$lang['wog_fight_no_date'] = '資料未建立';
$lang['wog_fight_cant_fight1'] = '秒內不能戰鬥';
$lang['wog_fight_over_time'] = '戰鬥超過 %s 回合';
$lang['wog_fight_cant_fight2'] = '3秒內不能戰鬥 or 不能使用上一頁方式比賽';

$lang['wog_fight_cp_money'] = '挑戰冠軍最少需';
$lang['wog_fight_cant_fight_me'] = '不能挑戰自己';

$lang['wog_fight_cant_pk1'] = '沒有選擇對象不能PK';
$lang['wog_fight_cant_pk2'] = '對方沒錢參加PK挑戰';

$lang['wog_fight_cant_pk3'] = '對手拒絕PK 或 PK條件不符合';

$lang['wog_fight_no_select'] = '無對手可以挑戰';

$lang['wog_fight_time'] = '開打時間 ';
$lang['wog_fight_no_group'] = '沒有選擇敵方工會';
$lang['wog_fight_no_area'] = '沒有選擇進攻領土';
$lang['wog_fight_select_error'] = '錯誤選擇';
$lang['wog_fight_break_area'] = '敵方領土已被破壞,請重新選擇';
$lang['wog_fight_no_ch'] = '無參戰角色';
$lang['wog_fight_no_join_group'] = '無加入工會,無法參加戰鬥';
$lang['wog_fight_no_number'] = '兵力為0,無法參加戰鬥';

$lang['wog_fight_pk_money'] = '挑戰對方最少需';
?>