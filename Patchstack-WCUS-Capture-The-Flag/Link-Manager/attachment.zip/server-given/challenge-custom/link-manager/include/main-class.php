<?php

// Block direct access to file
defined( 'ABSPATH' ) or die( 'Not Authorized!' );

if ( ! defined( 'WPS_FILE' ) ) {
    define( 'WPS_FILE', __FILE__ );
}
if ( ! defined( 'WPS_TEXT_DOMAIN' ) ) {
    define( 'WPS_TEXT_DOMAIN', 'wps-text-domain' );
}
if ( ! defined( 'WPS_DIRECTORY_BASENAME' ) ) {
    define( 'WPS_DIRECTORY_BASENAME', basename( dirname( __FILE__ ) ) );
}
if ( ! defined( 'WPS_DIRECTORY_URL' ) ) {
    define( 'WPS_DIRECTORY_URL', plugins_url( '', __FILE__ ) );
}

register_uninstall_hook( WPS_FILE, 'plugin_uninstall' );

register_activation_hook( WPS_FILE, 'plugin_activate' );
register_activation_hook( __FILE__, 'create_table' );
register_deactivation_hook( WPS_FILE, 'plugin_deactivate' );

add_action( 'plugins_loaded', 'plugin_init' );
add_action( 'wp_enqueue_scripts', 'plugin_enqueue_scripts' );
add_action( 'admin_enqueue_scripts', 'plugin_enqueue_admin_scripts' );
add_action( 'admin_menu', 'plugin_admin_menu_function' );

function plugin_uninstall() { }

function plugin_activate() { }

function plugin_deactivate() { }

function plugin_init() {
    load_plugin_textdomain( WPS_TEXT_DOMAIN, false, dirname( WPS_DIRECTORY_BASENAME ) . '/languages' );
}

function plugin_admin_menu_function() {
    add_menu_page( __('WordPress Link Manager', WPS_TEXT_DOMAIN), __('Link Manager', WPS_TEXT_DOMAIN), 'administrator', 'wps-general', null, 'dashicons-admin-generic', 4 );

    add_submenu_page( 'wps-general', __('General', WPS_TEXT_DOMAIN), __('General', WPS_TEXT_DOMAIN), 'manage_options', 'wps-general', 'plugin_settings_page' );
    add_submenu_page( 'wps-general', __('Plugin Support Page', WPS_TEXT_DOMAIN), __('Support', WPS_TEXT_DOMAIN), 'manage_options', 'wps-support', 'plugin_support_page' );

    add_action( 'admin_init', 'plugin_register_settings' );
}

function plugin_register_settings() {
    register_setting( 'wps-settings-group', 'example_option' );
    register_setting( 'wps-settings-group', 'another_example_option' );
}

function plugin_enqueue_admin_scripts() {
    wp_register_style( 'wps-admin-style', WPS_DIRECTORY_URL . '/assets/dist/css/admin-style.css', array(), null );
    wp_register_script( 'wps-admin-script', WPS_DIRECTORY_URL . '/assets/dist/js/admin-script.min.js', array(), null, true );
    wp_enqueue_script('jquery');
    wp_enqueue_style('wps-admin-style');
    wp_enqueue_script('wps-admin-script');

    wp_register_script('wps-ajax-script', WPS_DIRECTORY_URL . '/assets/dist/js/user-script.min.js', array('jquery'), null, true );
    wp_localize_script('wps-ajax-script', 'ajax_params', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('ajax_submit_link')
    ));
    wp_enqueue_script('wps-ajax-script');
}

function plugin_enqueue_scripts() {
    wp_register_style( 'wps-user-style', WPS_DIRECTORY_URL . '/assets/dist/css/user-style.css', array(), null );
    wp_register_script( 'wps-user-script', WPS_DIRECTORY_URL . '/assets/dist/js/user-script.min.js', array(), null, true );
    wp_enqueue_script('jquery');
    wp_enqueue_style('wps-user-style');
    wp_enqueue_script('wps-user-script');
}

add_action( 'wp_ajax_submit_link', 'handle_ajax_link_submission' );
add_action( 'wp_ajax_nopriv_submit_link', 'handle_ajax_link_submission' );

function handle_ajax_link_submission() {
    // Strictly check for nonce
    check_ajax_referer('ajax_submit_link', 'nonce');

    $url = esc_url_raw($_POST['url']); 
    $name = sanitize_text_field($_POST['name']); 
    $description = sanitize_textarea_field($_POST['description']); 

    $image = ''; 
    $visible = 'Y';
    $owner = get_current_user_id(); 
    $rating = 0; 
    $updated = current_time('mysql');
    $rel = ''; 
    $notes = ''; 

    global $wpdb;
    $table_name = $wpdb->prefix . 'links';
    $wpdb->insert(
        $table_name,
        array(
            'link_url' => $url,
            'link_name' => $name,
            'link_image' => $image,
            'link_description' => $description,
            'link_visible' => $visible,
            'link_owner' => $owner,
            'link_rating' => $rating,
            'link_updated' => $updated,
            'link_rel' => $rel,
            'link_notes' => $notes,
        ),
        array(
            '%s',
            '%s', 
            '%s', 
            '%s', 
            '%s', 
            '%d',
            '%d', 
            '%s',
            '%s', 
            '%s',
        )
    );

    if ($wpdb->last_error) {
        echo $wpdb->last_error;
    }
    
    wp_send_json_success('Link data submitted successfully!');
}

add_action('wp_ajax_get_link_data', 'get_link_data');
add_action('wp_ajax_nopriv_get_link_data', 'get_link_data');

function get_link_data() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'links';
    $link_name = sanitize_text_field($_POST['link_name']);
    $order = sanitize_text_field($_POST['order']);
    $orderby = sanitize_text_field($_POST['orderby']);

    validate_order($order);
    validate_order_by($orderby);
    
    $results = $wpdb->get_results("SELECT * FROM wp_links where link_name = '$link_name' order by $orderby $order");

    if (!empty($results)) {
        wp_send_json_success($results);
    } else {
        wp_send_json_error('No data found.');
    }
}

function validate_order($input) {
    $allowed_order = array('ASC', 'DESC');

    $input_upper = strtoupper($input);

    if (in_array($input_upper, $allowed_order)) {
        return true;
    } else {
        return new WP_Error('invalid_order', 'Invalid order direction. Only ASC or DESC are allowed.');
    }
}

function validate_order_by($input) {
    $allowed_orderby = array('link_name', 'link_url');

    $input_upper = strtoupper($input);

    if (in_array($input_upper, $allowed_orderby)) {
        return true;
    } else {
        return new WP_Error('invalid_order', 'Invalid order direction. Only link_name or link_url are allowed.');
    }
}

add_action('wp_footer', 'add_footer');

function add_footer() {
    if (is_front_page() || is_home()) {
        ?>
        <script type="text/javascript">
            var ajaxNonce = '<?php echo wp_create_nonce('ajax_submit_link'); ?>';
        </script>
        <?php
    }
}


function plugin_settings_page() { ?>
    <div class="wrap card">
        <h1><?php _e( 'WordPress Link Manager', WPS_TEXT_DOMAIN ); ?></h1>
        <p><?php _e( 'Welcome to WordPress Link Manager', WPS_TEXT_DOMAIN ); ?></p>
    </div>
<?php }

function plugin_support_page() {
    global $wpdb, $wp_version;
    $plugin = get_plugin_data( WPS_FILE, true, true );
    $wptheme = wp_get_theme();
    $current_user = wp_get_current_user();

    $user_fullname = ($current_user->user_firstname || $current_user->user_lastname) ?
        ($current_user->user_lastname . ' ' . $current_user->user_firstname) : $current_user->display_name; ?>
    
    <div class="wrap card">
        <h1><?php _e( 'Link Manager Support', WPS_TEXT_DOMAIN ); ?></h1>
        <p><?php _e( 'Please report this information when requesting support via mail.', WPS_TEXT_DOMAIN ); ?></p>
        <div class="support-debug">
            <div class="plugin">
                <ul>
                    <li class="support-plugin-version"><strong><?php _e($plugin['Name']); ?></strong> version: <?php _e($plugin['Version']); ?></li>
                    <li class="support-credits"><?php _e( 'Plugin author:', WPS_TEXT_DOMAIN ); ?> <a href="<?php echo $plugin['AuthorURI']; ?>"><?php echo $plugin['AuthorName']; ?></a></li>
                </ul>
            </div>
            <div class="theme">
                <ul>
                    <li class="support-theme-version"><?php printf( _('Active theme %s version: %s', WPS_TEXT_DOMAIN), $wptheme->Name, $wptheme->Version ); ?></li>
                </ul>
            </div>
            <div class="system">
                <ul>
                    <li class="support-php-version"><?php _e( 'PHP version:', WPS_TEXT_DOMAIN ); ?> <?php _e(PHP_VERSION); ?></li>
                    <li class="support-mysql-version"><?php _e( 'MySQL version:', WPS_TEXT_DOMAIN ); ?> <?php _e( mysqli_get_server_info( $wpdb->dbh ) ); ?></li>
                    <li class="support-wp-version"><?php _e( 'WordPress version:', WPS_TEXT_DOMAIN ); ?> <?php _e($wp_version); ?></li>
                </ul>
            </div>
        </div>
        <div class="support-action">
            <button type="button" class="button" name="Send Mail">
                <a style="text-decoration: none" href="mailto:someone@example.com?Subject=Plugin%20Support">Mail Me</a>
            </button>
        </div>
    </div>
<?php }
