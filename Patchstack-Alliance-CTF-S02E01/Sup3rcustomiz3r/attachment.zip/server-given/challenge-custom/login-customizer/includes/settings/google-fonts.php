<?php
/**
 * Login Customizer Localize Google Fonts
 *
 * @package Login Customizer
 */

defined( 'ABSPATH' ) || exit;

$wp_customize->add_setting(
	'login_customizer[localize_fonts]',
	array(
		'type'              => 'option',
		'transport'         => 'postMessage',
		'sanitize_callback' => 'sanitize_text_field',
	)
);
$wp_customize->add_control(
	new Login_Customizer_Localize_Google_Fonts(
		$wp_customize,
		'login_customizer[localize_fonts]',
		array(
			'type'    => 'login-customizer-localize-google-fonts',
			'label'   => esc_attr__( 'Import Google Fonts', 'login-customizer' ),
			'section' => 'login_customizer__section--file-import-export',
		)
	)
);

