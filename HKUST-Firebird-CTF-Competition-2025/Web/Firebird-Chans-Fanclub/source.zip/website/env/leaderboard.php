<?php
include 'db_connection.php';
session_start();
date_default_timezone_set("Asia/Hong_Kong");
error_reporting(0);

$question = '';
$solutions = []; 
$played = 0; 

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] === false) {
    session_destroy();
    header("Location: /login.php");
    die();
}

?>

<!DOCTYPE html>
<html>

<head>
    <style>
    <?php include 'style.css';
    ?>
    </style>
    <title>Home - Firebird Chan's Fanclub</title>
</head>

<body>
    <div class="container hero is-fullheight">

        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="/register.php">
                        Register
                    </a>
                    <a class="navbar-item" href="/login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="/play.php">
                        Play
                    </a>
                    <a class="navbar-item" href="/leaderboard.php">
                        Leaderboard
                    </a>
                    <a class="navbar-item" href="/flag.php">
                        Flag (For Members Only)
                    </a>
                    <a class="navbar-item" href="/logout.php">
                        Logout
                    </a>
                </div>

                <div class="navbar-end">
                    <div class="navbar-item">
                        <div class="buttons">
                            <a class="button is-primary" href="https://www.youtube.com/watch?v=Gc5NIjuAmU4&list=PLuxqoToY7UciHpW1-lDtgThiW4UbbyQ4_">
                                Hi, <?php echo $_SESSION['username'];?>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </nav>

        <section class="section">
            <div class="container">
                <h3 class="title is-3">Leaderboard</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th><abbr title="Position">Pos</abbr></th>
                            <th>Username</th>
                            <th><abbr title="Points">Points</abbr></th>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th><abbr title="Position">Pos</abbr></th>
                            <th>Username</th>
                            <th><abbr title="Points">Points</abbr></th>
                            <th>Role</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php 
                        $conn = OpenCon();
                        $stmt = $conn->prepare("SELECT * FROM scores ORDER BY Score DESC;");
                        $stmt->execute();
                        $res = $stmt->get_result();
                        $index = 1;
                        while ($row = $res->fetch_array(MYSQLI_NUM)) {
                            echo '
                            <tr>
                                <th>' . $index . '</th>
                                <td>' . $row[0] . '</td>
                                <td>' . $row[1] . '</td>
                                <td>' . $row[2] . '</td>
                            </tr>';
                            $index += 1;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>

        <footer class="has-text-centered mt-auto pt-5 pb-5">
            <p>Styled with <a href="https://bulma.io/">Bulma</a>. </p>
        </footer>

    </div>

</body>

</html>