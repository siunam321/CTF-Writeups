<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
* JOTAC_Plugin_Admin Class
*

*/


final class JOTAC_Plugin_Admin {
        /**
        * JOTAC_Plugin_Admin The single instance of JOTAC_Plugin_Admin.
        * @var object
        * @access private
        * @since 1.0.0
        */
        
        private static $_instance = null;
        
        
        /**
        * Constructor function.
        */
        public function __construct () {
            // Register the settings with WordPress.
            add_action( 'admin_init', array( $this, 'register_settings' ) );
            // Register the settings screen within WordPress.
            add_action( 'admin_menu', array( $this, 'register_settings_screen' ) );
        
            // Add toolbar link to JOT
            add_action( 'admin_bar_menu', array($this,'add_jot_toolbar_link'), 999);
        } // End __construct()
        
        /**
        * Main JOTAC_Plugin_Admin Instance
        *
        * Ensures only one instance of JOTAC_Plugin_Admin is loaded or can be loaded.
        *
        */
        public static function instance () {
            if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
        } // End instance()
        
        /**
        * Register the admin screen.
        */
        public function register_settings_screen () {
            //$this->_hook = add_submenu_page( 'options-general.php', __( 'JOT Plugin Settings', 'jotac-plugin' ), __( 'JOT Settings', 'jotac-plugin' ), 'manage_options', 'jotac-plugin', array( $this, 'settings_screen' ) );
            add_menu_page(__('Messaging', 'jotac-plugin'), __('Messaging', 'jotac-plugin'), 'manage_options', 'jotac-plugin', array( $this, 'settings_screen' ),'dashicons-phone');
        } // End register_settings_screen()
        
        /**
        * add a link to the WP Toolbar
        */
        function add_jot_toolbar_link($wp_admin_bar) {
            $toolbar_label = __( 'JOT', 'jotac-plugin' );
            $toolbar_label = apply_filters('jot_whitelabel_dashboard_admin_toolbar_label',$toolbar_label);
            
            $args = array(
                'id' => 'jot-messages-toolbar',
                'title' => '<span class="ab-icon"></span><span class="ab-label">'. $toolbar_label .'</span>', 
                'href' => admin_url('admin.php?page=jotac-plugin'), 
                'meta' => array(
                    'target'=> '_self',
                    'class' => 'jot-messages-toolbar', 
                    'title' => 'JOT Messaging'
                    )
            );
            $wp_admin_bar->add_node($args);
        }
        
        /**
        * Output the markup for the settings screen.
        */
        public function settings_screen () {
            global $title;
            $sections = JOTAC_Plugin()->settings->get_settings_sections();
            $tab = $this->_get_current_tab( $sections );
            
            
            $subform = $this->get_subform();
            $tabform = $tab . "-" . $subform;
            
            echo wp_kses_post($this->get_admin_header_html( $sections, $title ));
            switch ( $tabform ) {
                case 'smsprovider-main'; 
                    $this->write_smsprovider_fields($sections, $tab);          
                break;
                case 'messages-main':
                    $this->write_message_fields($sections, $tab);
                break;
                case 'group-list-main':
                    $this->write_group_list_fields($sections, $tab);
                break;
                default:
                   do_action("jot_render_extension_tab",$tabform);
                break;
            }
                    
        } // End settings_screen()
            
            
        /**
        * Write out message_fields tab screen
        */    
        public function write_smsprovider_fields($sections,$tab) {
            
            echo "<form id=\"smsprovider-fields-form\" action=\"options.php\" method=\"post\">";
            settings_fields( 'jotac-plugin-settings-' . $tab );
                        
            $pagehtml = JOTAC_Plugin()->settings->render_smsprovider_settings($sections,$tab);
            echo wp_kses($pagehtml['html'], JOTAC_Plugin()->settings->allowed_html_tags());
                                    
            if (isset($_GET['section']))  {
               // Don't display Save button on Get Started or system info tabs
               $section_name = sanitize_text_field($_GET['section']);
               if ($section_name != 'getstarted' && $section_name != 'systeminfo' && $section_name != 'licencekeys')  {
                   submit_button( __(  $sections[$tab]['buttontext'], 'jotac-plugin' ) );
               }
            }
            
            echo "</form>";
            echo "<br>";
            
            // Display a guidance messages
            $auth = get_option('jotac-plugin-smsprovider');
            $selected_provider = JOTAC_Plugin()->currentsmsprovidername;
            if (isset($auth['jot-accountsid-' . $selected_provider])) {
                $sid = $auth['jot-accountsid-' . $selected_provider];
            } else {
                $sid = null;
            }
            $guidance = "";
            
            if (!is_null($sid)) {               
                if ($pagehtml['message_code'] !=0 ) {
                    $guidance = $pagehtml['message_text'];
                    $cssclass = "jot-messagered";
                } else {
                    if ( JOTAC_Plugin()->settings->get_current_smsprovider_number() == 'default') {
                       $guidance = __( 'Please select your "from" number and save.', 'jotac-plugin' );
                        $cssclass = "jot-messagered";
                    } else {
                        $guidance = $pagehtml['message_text'];
                        $cssclass = "jot-messagegreen";
                    }
                } 
            }
            
            
            echo "<div id=\"jot-messagestatus\" class=\"". esc_attr($cssclass) . "\">" . esc_html($guidance) . "</div>";
            
            $this->write_page_footer();
           
        }
        
        /**
        * Write out message_fields tab screen
        */
        public function write_message_fields($sections,$tab) {
            
            echo "<form id=\"jot-message-field-form\" action=\"\" method=\"post\">";
            settings_fields( 'jotac-plugin-settings-' . $tab );
            
            echo wp_kses(JOTAC_Plugin()->settings->render_message_panel($sections,$tab), JOTAC_Plugin()->settings->allowed_html_tags());
                        
            echo "<a href=\"#\" class=\"button button-primary\" id=\"jot-sendmessage\">" . __("Send your message","jotac-plugin") . "</a>"; 
            echo "</form>";
            echo "<br>";
            echo "<div id=\"jot-messagestatus\"></div>";
            echo "<div id=\"jot-sendstatus-div\">";
            echo "</div>";
            
            $this->write_page_footer();
            
        }
        
        public function write_group_list_fields($sections,$tab) {            
           
            echo "<form id=\"group-list-fields-form\" action=\"\" method=\"post\">";
            echo "<input type=\"hidden\"  name=\"jot-form-id\" value=\"jot-group-add\">";
            settings_fields( 'jotac-plugin-settings-' . $tab );            
            echo "</form>";
            echo "<br>";
            echo "<br>";
            echo "<br>";
            
            
            $lastid = JOTAC_Plugin()->lastgrpid;
            wp_localize_script( 'jot-js', 'jot_lastgroup',
		       array( 'id' => $lastid ) );
            
            echo wp_kses(JOTAC_Plugin()->settings->render_grouplisttabs(), JOTAC_Plugin()->settings->allowed_html_tags());
            echo wp_kses(JOTAC_Plugin()->settings->render_groupdetails($sections, $tab, $lastid), JOTAC_Plugin()->settings->allowed_html_tags());
            echo wp_kses(JOTAC_Plugin()->settings->render_groupmembers($sections, $tab, $lastid), JOTAC_Plugin()->settings->allowed_html_tags());
            echo wp_kses(JOTAC_Plugin()->settings->render_groupinvites($sections, $tab, $lastid), JOTAC_Plugin()->settings->allowed_html_tags());
                                    
            do_action("jot_render_extension_subtab",$sections, $tab, $lastid);
                        
            $this->write_page_footer();         
        }
        
        public function write_page_footer() {
            
            echo "<br>";
            echo "<br>";
            echo "<br>";
            echo "<br>";
            echo "<div class='jot-footer-upgrade'>" . __("Upgrade to the ","jotac-plugin") . "<a href='https://www.loadedpenguin.com/' target='_blank'>" .  __("Pro Version","jotac-plugin") . "</a>.";
            echo "</div>";
        }
        
        
        /**
        * Register the settings within the Settings API.
        */
        public function register_settings () {
                           
                    register_setting( 'jotac-plugin-settings-smsprovider', 'jotac-plugin-smsprovider',array($this,'sanitise_sms_settings'));
                    register_setting( 'jotac-plugin-settings-messages', 'jotac-plugin-messages');
                    register_setting( 'jotac-plugin-settings-group-list', 'jotac-plugin-group-list');
                    register_setting( 'jotac-plugin-settings-woocommerce', 'jotac-plugin-woo-manager');
                    
        } // End register_settings()
        
        
        
        
        public function sanitise_sms_settings($input) {
            
            $debug = false;
            
                                    
            if ( empty( $_POST['_wp_http_referer'] ) ) {
		return $input;
            }
            parse_str( $_POST['_wp_http_referer'], $referrer );
            
            if (isset($referrer['tab'])) {                 
                   $tab = sanitize_text_field($referrer['tab']);
            } else {
                   return $input;
            }
            
            //Debug
            if ($debug) {
                $fields = JOTAC_Plugin()->settings->get_settings_fields($tab);
                echo "<br>Saved";
                var_dump($fields);
                echo "<br><br><hr><br><br>Input<br>";
                var_dump($input);
            }
            //Debug
            
                        
            if (isset($referrer['section'])) {                 
                   $sectiontab = $referrer['section'];
            } else {
                   return $input;
            }
            
            if (isset($referrer['subsection'])) {                 
                   $subsectiontab = $referrer['subsection'];
            } else {
                   $subsectiontab = "";
            }
                        
            $input = $input ? $input : array();
            
            // Trim Twilio details
            if (isset($input['jot-accountsid-twilio'])) {
                $input['jot-accountsid-twilio'] = trim(sanitize_text_field($input['jot-accountsid-twilio']));
            }
            if (isset($input['jot-authsid-twilio'])) {
                $input['jot-authsid-twilio'] = trim(sanitize_text_field($input['jot-authsid-twilio']));
            
            }
            
            // Get existing settings array
            $smsdetails       = get_option('jotac-plugin-smsprovider') ? get_option('jotac-plugin-smsprovider') : array() ;
            
            // If there are fields of type checkbox for this tab, that are not in input then set them to false            
            $fields = JOTAC_Plugin()->settings->get_settings_fields($tab);
            							   
            foreach ($fields as $key => $value) {
                if (isset($value['sectiontab'])) {
                    if ($value['type'] == 'checkbox' && $value['sectiontab'] == $sectiontab) {                          
                        if (array_key_exists($key, $input)) {
                            // Key found in input array                            
                        } else {
                            // Key not found in input array, so give it false values.
                            if (isset($value['options']) ) {
                                // Handle multi value checkboxes
                                if ($debug) {
                                    echo "<br>" . $value['subsection'] . "<>" .  $subsectiontab;
                                }
                                if ($value['subsection'] == $subsectiontab) {                                                                
                                    $input[$key] = array();  
                                }                                
                            } else {
                                // Not multi value - key not found so add it into the input array
                                $input[$key] = false;                            
                            }
                        }
                    }
                }
            }
            
            //Validate all input fields
            foreach ($input as $input_key => $input_value) {
                
                if ($debug) {
                    if (is_array($input[$input_key])) {
                        echo "<br>IN :" . $input_key . " " . print_r($input[$input_key],true);    
                    } else {
                        echo "<br>IN :" . $input_key . " " . $input_value;    
                    }  
                }
                
                if (isset($fields[$input_key]['validate'])) {
                    $validate_filter = $fields[$input_key]['validate'];
                } else {
                    $validate_filter = "";    
                }
                
                if (is_array($input[$input_key])) {
                    //Input is an array of values
                    $validated_subarray = array();
                    foreach ($input[$input_key] as $sub_array_key => $sub_array_value) {
                        $validated_subarray[$sub_array_key] = $this->validation_filter($validate_filter,$sub_array_value);                        
                    }
                    $input[$input_key] = $validated_subarray;
                } else {
                    //Not an array of values
                    $input[$input_key] = $this->validation_filter($validate_filter,$input_value);                    
                }
                
                if ($debug) {
                    if (is_array($input[$input_key])) {
                        echo "<br>OUT :" . print_r($input[$input_key],true);    
                    } else {
                        echo "<br>OUT :" . $input[$input_key];    
                    }                
                    echo "<br>======================";    
                }
                
            }            
            
            // Merge new settings with existing settings (priority goes to left hand array)
            if (is_array($input) && is_array($smsdetails)){
                $smsdetails_merge = $input + $smsdetails;
            } else {
                $smsdetails_merge = array();
                if (!is_array($input)) {                
                    add_settings_error('jot_settings_notice', 'jot_input_array_error', "Unable to save settings. (Error with input array)", "error");
                } else {
                    $smsdetails_merge = $input;
                }
                if (!is_array($smsdetails)) {
                    add_settings_error('jot_settings_notice', 'jot_provider_array_error', "Unable to save settings. (Error with provider array)", "error");
                }  else {
                    $smsdetails_merge = $smsdetails;
                }
            }
            
            //Debug
            if ($debug) {
                echo "<br><br><hr><br><br>Input after processing<br>"; 
                var_dump($input); 
                echo "<br><br><hr><br><br>Output<br>"; 
                var_dump($smsdetails_merge); 
                exit; 
            }
            //Debug
            
            return apply_filters('jot-sanitise-sms-settings',$smsdetails_merge,$input);
        }
        
        
        public function validation_filter($validate_filter,$input_value) {
            
            switch ( $validate_filter ) {
                    case 'email';
                        $input_value = sanitize_email($input_value);                        
                    break;
                    case 'url':                        
                        $input_value = sanitize_url($input_value);                          
                    break;
                    case 'textarea':                        
                        $input_value = sanitize_textarea_field($input_value);                          
                    break;    
                    default:
                        $input_value = sanitize_text_field($input_value);   
                    break;
            }
            
            return $input_value;
            
        }
        
        
        /**
        * Return marked up HTML for the header tag on the settings screen.
        */
        public function get_admin_header_html ( $sections, $title ) {
            $response = '';
            $defaults = array(
            'tag' => 'h2',
            'atts' => array( 'class' => 'jotac-plugin-wrapper' ),
            'content' => $title
            );
            $args = $this->_get_admin_header_data( $sections, $title );
            $args = wp_parse_args( $args, $defaults );
            $atts = '';
            if ( 0 < count ( $args['atts'] ) ) {
                foreach ( $args['atts'] as $k => $v ) {
                    $atts .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
                }
            }
            $response = '<' . $args['tag']  . $atts . '>' . $args['content'] . '</' . $args['tag']  . '>' . "\n";
            return $response;
        } // End get_admin_header_html()
       
        /**
        * Return the current tab key.
        */
        private function _get_current_tab ( $sections = array() ) {
            if ( isset ( $_GET['tab'] ) ) {
                $response = sanitize_title_with_dashes( $_GET['tab'] );
            } else {
                if ( is_array( $sections ) && ! empty( $sections ) ) {
                list( $first_section ) = array_keys( $sections );
                $response = $first_section;
                } else {
                $response = '';
                }
            }
            return $response;
        } // End _get_current_tab()
        
        /**
        * Return the current subform key.
        */
        
        private function get_subform () {
            if ( isset ($_GET['subform']) ) {
                $response = sanitize_title_with_dashes( $_GET['subform'] );
            } else {
                $response = 'main';               
            }
            return $response;
        } // End _get_current_tab()
       
        
        /**
        * Return an array of data, used to construct the header tag.
        */
        private function _get_admin_header_data ( $sections, $title ) {
            $response = array( 'tag' => 'h2', 'atts' => array( 'class' => 'jotac-plugin-wrapper' ), 'content' => $title );
                if ( is_array( $sections ) && 1 < count( $sections ) ) {
                $response['content'] = '';
                $response['content'] = '<a href="http://www.loadedpenguin.com/lite-documentation/" target="_blank" class="nav-tab" id="jot-help" title="Help"><img src="' . plugins_url( 'images/Help.png', dirname(__FILE__) ) .  '" title="Help" id="jot-help-image"></a>';
                $response['atts']['class'] = 'nav-tab-wrapper';
                $tab = $this->_get_current_tab( $sections );
                foreach ( $sections as $key => $value ) {
                    $class = 'nav-tab';
                    if ( $tab == $key ) {
                    $class .= ' nav-tab-active';
                    }
                    $response['content'] .= '<a href="' . admin_url( 'admin.php?page=jotac-plugin&tab=' . sanitize_title_with_dashes( $key ) ) . '" class="' . esc_attr( $class ) . '">' . esc_html( $value['tabname']) . '</a>';
                }
            }
            return (array)apply_filters( 'jotac-plugin-get-admin-header-data', $response );
        } // End _get_admin_header_data()

} // End Class