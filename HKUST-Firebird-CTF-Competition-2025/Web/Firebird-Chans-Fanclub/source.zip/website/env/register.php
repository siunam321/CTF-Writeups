<?php
include 'db_connection.php';
session_start();
date_default_timezone_set("Asia/Hong_Kong");
error_reporting(0);

$notice = '';

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: /index.php");
    die();
}

if (isset($_POST['username']) && isset($_POST['password']) && !empty($_POST['username']) && !empty($_POST['password'])) {
    $role = "Guest";
    $hashed_password = password_hash($_POST['password'], PASSWORD_ARGON2ID, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]);
    $conn = OpenCon();
    $stmt = $conn->prepare("INSERT INTO users (Username, Password) VALUES (?, ?);");
    $stmt->bind_param("ss", $_POST['username'], $hashed_password);
    $res = $stmt->execute();
    if ($res === true) {
        $stmt = $conn->prepare("UPDATE users SET Role = ? WHERE Username = ?;");
        $stmt->bind_param("ss", $role, $_POST['username']);
        $stmt->execute();
        CloseCon($conn);
        header("Location: /login.php?register=true");
        die();
    } else {
        CloseCon($conn);
        $notice = '
        <section class="message is-danger">
            <div class="message-header">
                <p>Error</p>
            </div>
            <div class="message-body">
                Username already exists.
            </div>
        </section>
        ';
    }
} else {
    if (!isset($_POST['username']) && !isset($_POST['password'])) {
        ;
    } else {
        $notice = '
        <section class="message is-danger">
            <div class="message-header">
                <p>Error</p>
            </div>
            <div class="message-body">
                Please input username and password.
            </div>
        </section>
        ';
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <style>
    <?php include 'style.css';
    ?>
    </style>
    <title>Home - Firebird Chan's Fanclub</title>
</head>

<body>
    <div class="container hero is-fullheight">

        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="/register.php">
                        Register
                    </a>
                    <a class="navbar-item" href="/login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="/play.php">
                        Play
                    </a>
                    <a class="navbar-item" href="/leaderboard.php">
                        Leaderboard
                    </a>
                    <a class="navbar-item" href="/flag.php">
                        Flag (For Members Only)
                    </a>
                    <a class="navbar-item" href="/logout.php">
                        Logout
                    </a>
                </div>
            </div>
        </nav>

        <section class="section">
            <?php echo $notice ?>
            <section class="hero is-link">
                <div class="hero-body">
                    <div class="container">
                        <h1 class="title">Firebird Chan's Fanclub</h1>
                        <h2 class="subtitle">Answer 5 Questions correctly to join the Firebird Chan Fanclub! (paying vow 10BTC may or
                            may not also work)</h2>
                    </div>
                </div>
            </section>
        </section>

        <h3 class="title is-3">Register</h3>

        <form action="/register.php" method="POST">
            <div class="field">
                <label class="label">Username</label>

                <div class="control">
                    <input class="input" type="text" placeholder="Username" name="username" />
                </div>

                <label class="label">Password</label>

                <div class="control">
                    <input class="input" type="text" placeholder="Password" name="password" />
                </div>
            </div>

            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-link" type="submit">Register</button>
                </div>
            </div>
        </form>

        <footer class="has-text-centered mt-auto pt-5 pb-5">
            <p>Styled with <a href="https://bulma.io/">Bulma</a>. </p>
        </footer>

    </div>

</body>

</html>