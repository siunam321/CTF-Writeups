<?php
/**
 * Uninstall Login Customizer.
 *
 * @package Login Customizer
 */

// Exit if accessed directly.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once 'login-customizer.php';

$login_customizer_page = Login_Customizer()->get_login_customizer_page();
$login_customizer_page = $login_customizer_page->ID;

wp_trash_post( $login_customizer_page );

delete_option( 'login_customizer' );
delete_option( 'login_customizer_settings' );
delete_option( 'login_customizer_license' );

wp_cache_flush();
