<?php
/**
 * Silence is golden.
 *
 * @package MWB_Point_Of_Sale_Woocommerce
 */

// Silence is golden.
