<?php
include 'db_connection.php';
session_start();
date_default_timezone_set("Asia/Hong_Kong");
error_reporting(0);

$question = '';
$solutions = []; 
$played = 0; 

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] === false) {
    session_destroy();
    header("Location: /login.php");
    die();
}

$conn = OpenCon();
$stmt = $conn->prepare("SELECT * FROM scores WHERE Username = ?;");
$stmt->bind_param("s", $_SESSION["username"]);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_array(MYSQLI_NUM);
CloseCon($conn);
if (!empty($row)) {
    $played = 1;
}  

if (isset($_POST['answer']) && $played === 0) {
    switch ($_SESSION["questionNum"]) {
        case 0:
            if ($_POST['answer'] === strval(1)) {
                $_SESSION["correctNum"] += 1;
                $_SESSION["questionNum"] += 1;
            } else {
                $_SESSION["questionNum"] += 1;
            }
            break;
        case 1:
            if ($_POST['answer'] === strval(0)) {
                $_SESSION["correctNum"] += 1;
                $_SESSION["questionNum"] += 1;
            } else {
                $_SESSION["questionNum"] += 1;
            }
            break;
        case 2:
            if ($_POST['answer'] === strval(3)) {
                $_SESSION["correctNum"] += 1;
                $_SESSION["questionNum"] += 1;
            } else {
                $_SESSION["questionNum"] += 1;
            }
            break;
        case 3:
            if ($_POST['answer'] === strval(0)) {
                $_SESSION["correctNum"] += 1;
                $_SESSION["questionNum"] += 1;
            } else {
                $_SESSION["questionNum"] += 1;
            }
            break;
        case 4:
            if ($_POST['answer'] === strval(0)) {
                // Let's rig the game >_<
                if ($_SESSION["role"] === "Member") {
                    $_SESSION["correctNum"] += 1;
                }
                $_SESSION["questionNum"] += 1;
            } else {
                $_SESSION["questionNum"] += 1;
            }
            break;
    }
} 

if ($played === 0) {
    switch ($_SESSION["questionNum"]) {
        case 0:
            $question = 'What color hair does Firebird Chan have?';
            $solutions = ["Black", "Red", "White", "Yellow"]; 
            break;
        case 1:
            $question = 'What clothes does Firebird Chan commonly wear?';
            $solutions = ["Hoodie", "T-shirt", "Blazer", "Dress"]; 
            break;
        case 2:
            $question = 'What is Firebird Chan\'s favourite hobby?';
            $solutions = ["Eating", "Sleeping", "Grinding Leng Grade in UST", "CTF"]; 
            break;
        case 3:
            $question = 'Do you love Firebird Chan?';
            $solutions = ["Yes", "No"]; 
            break;
        case 4:
            $question = 'Do you want to join Firebird Chan\'s Fanclub?';
            $solutions = ["Yes", "No"]; 
            break;
        case 5:
            $conn = OpenCon();
            $stmt = $conn->prepare("INSERT INTO scores (Username, Score, Role) VALUES (?, ?, ?);");
            $stmt->bind_param("sis", $_SESSION['username'], $_SESSION["correctNum"], $_SESSION["role"]);
            $stmt->execute();
            CloseCon($conn);
            header("Location: /leaderboard.php");
            die();
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <style>
    <?php include 'style.css';
    ?>
    </style>
    <title>Home - Firebird Chan's Fanclub</title>
</head>

<body>
    <div class="container hero is-fullheight">

        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="/register.php">
                        Register
                    </a>
                    <a class="navbar-item" href="/login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="/play.php">
                        Play
                    </a>
                    <a class="navbar-item" href="/leaderboard.php">
                        Leaderboard
                    </a>
                    <a class="navbar-item" href="/flag.php">
                        Flag (For Members Only)
                    </a>
                    <a class="navbar-item" href="/logout.php">
                        Logout
                    </a>
                </div>

                <div class="navbar-end">
                    <div class="navbar-item">
                        <div class="buttons">
                            <a class="button is-primary" href="https://www.youtube.com/watch?v=Gc5NIjuAmU4&list=PLuxqoToY7UciHpW1-lDtgThiW4UbbyQ4_">
                                Hi, <?php echo $_SESSION['username'];?>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </nav>

        <section class="section">
            <div class="container">
                <?php 
                if ($played === 0) {
                    echo '<progress class="progress is-primary" value="' . $_SESSION["questionNum"] . '" max="5"></progress>';
                } else {
                    ;
                }
                ?>
                <h3 class="title is-3">
                    <?php 
                    if ($played === 0) {
                        echo "Question #" . strval($_SESSION["questionNum"]+1);
                    } else {
                        echo "You have already played this quiz before!";
                    }
                    ?>
                </h3>
                <div class="content">
                    <?php 
                    if ($played === 0) {
                        echo $question;
                    } else {
                        echo "Make another account to play again!";
                    }
                    ?>
                </div>

                <?php
                if ($played === 0) {
                echo '<form method="POST">
                        <div class="field">
                            <div class="control">';
                foreach ($solutions as $key=>$solution) {
                    echo '<label for="answer-' . strval($key) . '">';
                    echo '<input id="answer-' . strval($key) . '"type="radio" name="answer" value="' . strval($key) . '" id="answer-0" required="">';
                    echo strval($solution);
                    echo '</label>';
                    echo '<br>';
                }
                echo '</div>
                    </div>
                    <div class="field is-grouped">
                        <div class="control">
                            <button class="button is-link" type="submit">Submit</button>
                        </div>
                    </div>
                </form>';
                } else {
                    ;
                }

                ?>
            </div>
        </section>

        <footer class="has-text-centered mt-auto pt-5 pb-5">
            <p>Styled with <a href="https://bulma.io/">Bulma</a>. </p>
        </footer>

    </div>

</body>

</html>