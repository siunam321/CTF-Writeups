<?php
session_start();
date_default_timezone_set("Asia/Hong_Kong");
error_reporting(0);

session_destroy();
header("Location: /login.php?logout=true");
die();
?>