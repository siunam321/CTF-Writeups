export default {
    flag: "corctf{t3st_fl4g}",
    password: "adminadmin"
};