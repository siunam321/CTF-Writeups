<?
/*===================================================== 
 Copyright (C) ETERNAL<iqstar.tw@gmail.com>
 Modify : 2005/01/29
 URL : http://www.2233.idv.tw
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
===================================================== */
$lang['wog_act_gowhere'] = '請重http://bbs.2233.idv.tw/wog/ 進入遊戲';
$lang['wog_act_nologin'] = '尚未登入遊戲 或 cookie失效無法正常執行遊戲';
$lang['wog_act_nofroum_member'] = '尚未登入論壇 或 尚未成為論壇會員不能進行遊戲';
$lang['wog_act_noid'] = '無此帳號';
$lang['wog_act_relogin'] = '請重新登入';
$lang['wog_act_nomoney'] = '金額不足';
$lang['wog_act_errmoney'] = '錯誤金額';
$lang['wog_act_errword'] = '請勿使用非法字元';
$lang['wog_act_errwork'] = '不當操作';
$lang['wog_act_errdate'] = '錯誤資料';
$lang['wog_act_nomoney_must'] = '金額不足 需%s元';
$lang['wog_act_check_cookie'] = 'COOKIE驗證失敗,請重新登入';
$lang['wog_act_nodata'] = '沒有填寫內容';
$lang['wog_act_nogenkey'] = '忘記輸入安全認證碼!';
$lang['wog_act_errgenkey'] = '錯誤認證碼!';
$lang['wog_act_logined'] = '相同論壇帳號在遊戲中';
$lang['wog_vip_message'] = '限贊助會員使用';
$lang['wog_act_errnum'] = '數量錯誤';
?>