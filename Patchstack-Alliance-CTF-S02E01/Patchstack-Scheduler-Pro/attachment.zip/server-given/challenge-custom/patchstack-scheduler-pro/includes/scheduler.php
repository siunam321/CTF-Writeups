<?php
class PatchstackSchedulerQueue {
    private $queue = array();
    private $db;
    
    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
    }
    
    public function add_to_queue($post_id, $schedule_time) {
        $this->queue[$post_id] = $schedule_time;
    }
    
    public function process_queue() {
        foreach ($this->queue as $post_id => $time) {
            $this->db->update('wp_posts', 
                array('post_status' => 'publish'),
                array('ID' => $post_id)
            );
        }
    }
} 