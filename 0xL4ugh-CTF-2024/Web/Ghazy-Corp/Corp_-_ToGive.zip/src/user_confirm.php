<?php
echo "<h1>Sorry, We Stopped account activation for a while due to an incedient. <Br>Please wait until we contact you again</h1>";
?>