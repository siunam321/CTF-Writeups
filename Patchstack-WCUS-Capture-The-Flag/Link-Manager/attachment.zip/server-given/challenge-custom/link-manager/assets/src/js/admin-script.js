(function ( $ ) {

	'use strict';

	console.info('Plugin admin script loaded.');

})( jQuery );
