## WordPress Link Manager

Ever after the "Link Manager" feature was dropped by WordPress on 3.5, I decided I had to write a plugin that would revive that feature. Here I go! The plugin is still on beta but the core working is completed.

## Note

This is not a clone of https://wordpress.org/plugins/link-manager, seriously!