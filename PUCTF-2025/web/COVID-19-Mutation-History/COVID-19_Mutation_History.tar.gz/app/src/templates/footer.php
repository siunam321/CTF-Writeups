<?php
defined("ADMIN_USERNAME") or die("No direct access");
?>

    </div>
</body>
</html>