<?php
/**
 * Template Name: Login Customizer
 *
 * Template to display the WordPress login form in the Customizer.
 * This is essentially a stripped down version of wp-login.php, though not accessible from outside the Customizer.
 *
 * @package Login Customizer
 */

$login_customizer_template = get_option( 'login_customizer', array( 'template' => 'default' ) );
$languages               = get_available_languages();

// Redirect if viewed from outside the Customizer.
if ( ! is_customize_preview() ) {

	// Pull the Login Customizer page from options.
	$logincustomizer_page = get_permalink( Login_Customizer()->get_login_customizer_page() );

	// Generate the redirect url.
	$logincustomizer_url = add_query_arg(
		array(
			'autofocus[section]' => 'login_customizer__section--templates',
			'return'             => admin_url( 'index.php' ),
			'url'                => rawurlencode( $logincustomizer_page ),
		),
		admin_url( 'customize.php' )
	);

	wp_safe_redirect( $logincustomizer_url );
}

/**
 * Output the login page header.
 *
 * @param string   $title    Optional. WordPress login Page title to display in the `<title>` element.
 *                           Default 'Log In'.
 * @param string   $message  Optional. Message to display in header. Default empty.
 * @param WP_Error $wp_error Optional. The error to pass. Default empty.
 */
function logincustomizer_login_header( $title = 'Log In', $message = '', $wp_error = '' ) {
	global $error, $action;

	// Don't index any of these forms.
	add_action( 'login_head', 'wp_no_robots' );

	if ( empty( $wp_error ) ) {
		$wp_error = new WP_Error();
	}

	$login_title = get_bloginfo( 'name', 'display' );

	/* translators: Login screen title. 1: Login screen name, 2: Network or site name */
	$login_title = sprintf( __( '%1$s &lsaquo; %2$s &#8212; WordPress', 'login-customizer' ), $title, $login_title );
	/**
	 * Filters the title tag content for login page.
	 *
	 *
	 * @param string $login_title The page title, with extra context added.
	 * @param string $title       The original page title.
	 */
	$login_title = apply_filters( 'login_title', $login_title, $title );
	?><!DOCTYPE html>
	<head>
	<title><?php echo esc_attr( $login_title ); ?></title>
	<?php
	wp_enqueue_style( 'login' );

	/**
	 * Enqueue scripts and styles for the login page.
	 */
	do_action( 'login_enqueue_scripts' );

	/**
	 * Fires in the login page header after scripts are enqueued.
	 */
	do_action( 'login_head' );
	?>
	</head>

	<?php
}

/**
 * Fires before a specified login form action.
 */
do_action( 'login_form_login' );

/**
 * Filters the separator used between login form navigation links.
 */
$login_link_separator = apply_filters( 'login_link_separator', ' | ' );

/**
 * Filters the login page errors.
 *
 *
 * @param object $errors      WP Error object.
 * @param string $redirect_to Redirect destination URL.
 */
logincustomizer_login_header( __( 'Log In' ), '', '' );

$login_header_url   = __( 'https://wordpress.org/' );
$login_header_title = __( 'Powered by WordPress' );

/**
 * Filters link URL of the header logo above login form.
 *
 * @param string $login_header_url Login header logo URL.
 */
$login_header_url = apply_filters( 'login_headerurl', $login_header_url );

/**
 * Filters the title attribute of the header logo above login form.
 *
 * @param string $login_header_title Login header logo title attribute.
 */
$login_header_title = apply_filters( 'login_headertext', $login_header_title );

unset( $login_header_url, $login_header_title );

/**
 * Filters the login page body classes.
 *
 * @param array  $classes An array of body classes.
 * @param string $action  The action that brought the visitor to the login page.
 */
$classes   = array( 'login-action-login', 'wp-core-ui' );
$classes[] = ' locale-' . sanitize_html_class( strtolower( str_replace( '_', '-', get_locale() ) ) );
$classes   = apply_filters( 'login_body_class', $classes, 'login' );
?>

	<body class="login <?php echo esc_attr( implode( ' ', $classes ) ); ?>">

	<div style="display: none !important; visibility: hidden;" id="login-customizer-template"><?php echo esc_attr( $login_customizer_template['template'] ); ?></div>

		<?php
		/**
		 * Fires in the login page header after the body tag is opened.
		 */
		do_action( 'login_header' );
		?>

		<div id="login-customizer--background-hint" data-hint="<?php echo esc_attr__( 'Click here to upload a background image, choose from the gallery and set a background color.', 'login-customizer' ); ?>" data-hintPosition="middle-right" data-position="bottom-right-aligned"></div>

		<div id="login-customizer--templates-hint" data-hint="<?php echo esc_attr__( 'Click here to select a display template for your login page.', 'login-customizer' ); ?>" data-hintPosition="middle-right" data-position="bottom"></div>

		<div id="login">

			<h1 id="login-customizer-logo-h1" class="wp-login-logo" data-hint="<?php echo esc_attr__( 'Click on the logo below to upload your own and set the image\'s height and width.', 'login-customizer' ); ?>" data-hintPosition="top-middle" data-position="right">
				<a id="login-customizer-logo" class="customize-unpreviewable" href="#" title="" tabindex="-1"><?php bloginfo( 'name' ); ?></a>
                <span id="login-customizer--ripple-effect-logo" class="login-customizer--username-svg-hover-display"></span>
			</h1>

			<?php
			$options    = new Login_Customizer_Customizer_Output();
			$option     = $options->option_wrapper( 'username_label' );
			$visibility = ( '' !== $option ) ? null : 'no-label';
			?>

			<form name="loginform" id="loginform" class="<?php echo esc_attr( $visibility ); ?>"  action="<?php echo esc_url( site_url( 'wp-login.php', 'login_post' ) ); ?>" method="post">
				<p>
					<label id="login-customizer--username-label" for="user_login">
						<span id="login-customizer--username-label-text">
							<span class="login-customizer--ripple-effect-username-label"></span>
							<span id="login-customizer-username-hover" class="login-customizer--username-svg-hover-display"></span>
							<?php echo esc_html__( 'Username or Email Address', 'login-customizer' ); ?>
						</span>
						<div id="login-customizer--username">
							<span class="login-customizer--ripple-effect-username-field"></span>
							<span id="login-customizer-username-field-hover" class="login-customizer--username-svg-hover-display"></span>
							<input readonly autocomplete="off" type="text" name="log" id="user_login" class="input" value="email@address.com" size="20" />
						</div>
					</label>
				</p>

				<p>
					<label id="login-customizer--password-label" for="user_pass">
						<span id="login-customizer--password-label-text">
							<span class="login-customizer--ripple-effect-username-label"></span>
							<span id="login-customizer-password-hover" class="login-customizer--username-svg-hover-display"></span>
							<?php echo esc_html__( 'Password', 'login-customizer' ); ?>
						</span>
				<div id="login-customizer--password">
					<span class="login-customizer--ripple-effect-username-field"></span>
					<span id="login-customizer-password-field-hover" class="login-customizer--username-svg-hover-display"></span>
					<input readonly autocomplete="off" type="password" name="pwd" id="user_pass" class="input" value="password" size="20" />
					<?php if ( version_compare( $GLOBALS['wp_version'], '5.2', '>' ) ) { ?>
						<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="<?php echo esc_attr__( 'Show Password', 'login-customizer' ); ?>">
							<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
						</button>
					<?php } ?>
				</div>
				</label>
				</p>

				<?php do_action( 'login_form' ); ?>

				<div class="login-customizer--form-footer">
					<p class="forgetmenot">
						<label for="rememberme">
							<span class="login-customizer--ripple-effect-remember-field"></span>
							<span id="login-customizer-remember-hover" class="login-customizer--username-svg-hover-display"></span>
							<input name="rememberme" type="checkbox" id="rememberme" value="forever" checked />
							<?php esc_html_e( 'Remember Me' ); ?>
							<span id="login-customizer-remember-label-hover" class="login-customizer--username-svg-hover-display"></span>
						</label>
					</p>

					<p class="submit">
						<span id="login-customizer--button">
							<span class="login-customizer--ripple-effect-submit-field"></span>
							<span id="login-customizer-submit-hover" class="login-customizer--username-svg-hover-display"></span>
							<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="<?php echo esc_html__( 'Log In', 'login-customizer' ); ?>" />
						</span>
					</p>
				</div>
			</form>

			<div id="login-customizer--below-form" data-hint="<?php echo esc_attr__( 'Click on the elements below the form to modify each one.', 'login-customizer' ); ?>" data-hintPosition="middle-right" data-position="bottom-right-aligned">
				<div class="login-customizer--ripple-effect-form-bellow-field"></div>
				<span id="login-customizer-bellow-form-field-hover" class="login-customizer--username-svg-hover-display"></span>

				<p id="nav">
					<?php
					if ( get_option( 'users_can_register' ) ) :
						$registration_url = sprintf( '<a href="%s">%s</a>', esc_url( wp_registration_url() ), __( 'Register', 'login-customizer' ) );
						echo esc_url( apply_filters( 'register', $registration_url ) );
						echo esc_html( $login_link_separator );
					endif;
					?>
					<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'login-customizer' ); ?></a>

				</p>

				<p id="backtoblog">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<?php
						/* translators: %s: site title */
						printf( _x( '&larr; Back to %s', 'site', 'login-customizer' ), esc_html( get_bloginfo( 'title', 'display' ) ) );
						?>
					</a>
				</p>

			</div>

			<?php
			if ( apply_filters( 'login_display_language_dropdown', true ) ) {
				$languages = get_available_languages();
				if ( ! empty( $languages ) ) {
					?>
					<div data-logincustomizer-template="template" class="language-switcher login-customizer--translation-switcher" id="template-language-translator" style="display: <?php echo isset( $login_customizer_template['template'] ) && 'default' !== $login_customizer_template['template'] ? 'block' : 'none'; ?>;position: relative">
						<form id="language-switcher" action="" method="get">
							<label for="language-switcher-locales">
								<span class="dashicons dashicons-translation" aria-hidden="true"></span>
								<span class="screen-reader-text"><?php esc_attr_e( 'Language' ); ?></span>
							</label>
							<select name="wp_lang" id="language-switcher-locales">
								<option value="en_US" data-installed="1" lang="en">English (United States)</option>
							</select>
							<input type="submit" class="button" value="<?php esc_attr_e( 'Change' ); ?>">
						</form>
					</div>
					<?php
				}
			}
			?>
		</div>

<?php
if ( apply_filters( 'login_display_language_dropdown', true ) ) {
	if ( ! empty( $languages ) ) {
		?>
			<div data-logincustomizer-template="default" class="language-switcher login-customizer--translation-switcher" id="default-language-translator" style="display: <?php echo isset( $login_customizer_template['template'] ) && 'default' === $login_customizer_template['template'] ? 'block' : 'none'; ?>;position: relative;">
				<form id="language-switcher" action="" method="get">
					<label for="language-switcher-locales">
						<span class="dashicons dashicons-translation" aria-hidden="true"></span>
						<span class="screen-reader-text"><?php esc_attr_e( 'Language' ); ?></span>
					</label>
						<select name="wp_lang" id="language-switcher-locales">
							<option value="en_US" data-installed="1" lang="en">English (United States)</option>
						</select>
					<input type="submit" class="button" value="<?php esc_attr_e( 'Change' ); ?>">
				</form>
			</div>
			<?php
	}
}
?>

		<?php do_action( 'login_footer' ); ?>

		<div class="clear"></div>
		<div id="login-customizer-background"></div>

	</body>

</html>

<?php
wp_footer();
