-- AlterTable
ALTER TABLE "public"."Board" ALTER COLUMN "content" SET DEFAULT '{}';
