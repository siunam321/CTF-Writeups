import subprocess

def main():
    print('Enter math expression:')
    script = input().replace('"','\\"').replace('\\','\\\\').replace("'","\\'")
    bad = "Object.keys(global).concat(module.constructor.builtinModules).concat(['require','module','globalThis']).filter((_)=>!/[@\\/-]/.test(_)).join(',')"
    jail = """'use strict';eval('(function('+%s+'){return eval("%s")})()')""" % (bad,script)
    proc = subprocess.Popen(["mongosh","--nodb","--quiet","--eval",jail], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(proc.stdout.read().decode())

if __name__ == '__main__':
    try:
        main()
    except:
        print('Unknown Error ??') # contact admin if you see this in production