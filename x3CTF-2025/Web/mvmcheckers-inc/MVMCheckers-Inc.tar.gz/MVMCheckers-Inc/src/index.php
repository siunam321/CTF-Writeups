<?php
include_once "header.php";
?>

<h1 class="text-center my-5">Bringing magic to you since 1970</h1>

<p class="text-center">Refer to the various sub-pages for information and configuration.</p>
