(function( $, $d, $w, variable ){
    $( '#rememberme' ).on( 'click', function( e ){
        e.preventDefault();
    } );
    $( '#login-customizer--username-label' ).hover( function(){
        $( '#login-customizer-username-hover' ).css( 'opacity', '100%' );
    }, function(){
        $( '#login-customizer-username-hover' ).css( 'opacity', '0' );
    } );
    $( '#login-customizer--password-label' ).hover( function(){
        $('#login-customizer-password-hover').css( 'opacity', '100%' );
    }, function(){
        $('#login-customizer-password-hover').css( 'opacity', '0' );
    } );
    $( '.login-customizer--form-footer' ).hover( function(){
        $( '#login-customizer-remember-hover' ).css( 'opacity', '100%' );
        $( '#login-customizer-remember-label-hover' ).css( 'opacity', '100%' );
    }, function(){
        $( '#login-customizer-remember-hover' ).css( 'opacity', '0' );
        $( '#login-customizer-remember-label-hover' ).css( 'opacity', '0' );
    } );
    $( '#login-customizer--button' ).hover( function(){
        $( '#login-customizer-submit-hover' ).css( 'opacity', '100%' );
    }, function(){
        $( '#login-customizer-submit-hover' ).css( 'opacity', '0' );
    } );
    $( '#login-customizer--username' ).hover( function(){
        $( '#login-customizer-username-field-hover' ).css( 'opacity', '100%' );
    }, function(){
        $( '#login-customizer-username-field-hover' ).css( 'opacity', '0' );
    } );
    $( '#login-customizer--password' ).hover( function(){
        $( '#login-customizer-password-field-hover' ).css( 'opacity', '100%' );
    }, function(){
        $( '#login-customizer-password-field-hover' ).css( 'opacity', '0' );
    } );
    $( '#login-customizer--below-form' ).hover( function(){
        $( '#login-customizer-bellow-form-field-hover' ).css( 'opacity', '100%' );
    }, function(){
        $( '#login-customizer-bellow-form-field-hover' ).css( 'opacity', '0' );
    } );
    $( '#login-customizer-logo-h1' ).hover( function(){
        $( '#login-customizer--ripple-effect-logo' ).css( 'opacity', '100%' );
    }, function(){
        $( '#login-customizer--ripple-effect-logo' ).css( 'opacity', '0' );
    } );
    $( '#user_login, #user_pass' ).on( 'click', function( e ){
        e.preventDefault();
    } );
    $( '#login-customizer-username-hover' ).on( 'click', function(){
        $( this ).parent().next()[0].click();
    } );
    $( '#login-customizer-password-hover' ).on( 'click', function(){
        $( this ).parent().next()[0].click();
    } );
    $( '#login-customizer-username-field-hover' ).on( 'click', function(){
        $( this ).next().next()[0].click();
    } );
    $( '#login-customizer-password-field-hover' ).on( 'click', function(){
        $( this ).next().next().next()[0].click();
    } );
    $( '#login-customizer-remember-hover' ).on( 'click', function(){
        $( this ).next().next().next()[0].click();
    } );
    $( '#login-customizer-submit-hover' ).on( 'click', function(){
        $( this ).next().next()[0].click();
    } );
    $( '#login-customizer-bellow-form-field-hover' ).on( 'click', function(){
        $( this ).next().next().next()[0].click();
    } );
    $( '#login-customizer-remember-label-hover' ).on( 'click', function(){
        $( this ).parent().next()[0].click();
    } );
    $( '#login-customizer--ripple-effect-logo' ).on( 'click', function(){
        $( this ).next()[0].click();
    } );
    $( '#language-switcher' ).on( 'submit', function( e ){
        e.preventDefault();
    } );
}( jQuery, document, window ));