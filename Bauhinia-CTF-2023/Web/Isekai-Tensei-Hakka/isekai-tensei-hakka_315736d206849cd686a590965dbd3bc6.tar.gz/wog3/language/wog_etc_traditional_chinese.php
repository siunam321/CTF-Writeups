<?
/*===================================================== 
 Copyright (C) ETERNAL<iqstar.tw@gmail.com>
 Modify : 2005/01/29
 URL : http://www.2233.idv.tw
 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
===================================================== */

//--------------top king----------
$lang['wog_etc_king_lv'] = '等級';
$lang['wog_etc_king_win'] = '勝場';
$lang['wog_etc_king_hp'] = 'hp';
$lang['wog_etc_king_ac'] = '物理攻擊';
$lang['wog_etc_king_mc'] = '魔法攻擊';
$lang['wog_etc_king_agl'] = '速度';
$lang['wog_etc_king_race'] = '鳥奪冠';
$lang['wog_etc_king_money'] = '好野人';
//--------------race----------
$lang['wog_etc_race_nobird'] = '請選擇要下注的鳥';
$lang['wog_etc_race_errorbird'] = '錯誤數量';
$lang['wog_etc_race_rerace'] = '請重新比賽';
$lang['wog_etc_race_lost'] = '很遺憾，您輸了';
$lang['wog_etc_race_win'] = '恭喜 %s 贏了，你的現金裏將增加 %d 元。';
//--------------email_password----------
$lang['wog_etc_email_body1'] = '以下是你在 Online FF Battle - WOG 中的帳號密碼';
$lang['wog_etc_email_body2'] = '帳號 : %s';
$lang['wog_etc_email_body3'] = '密碼 : %s';
$lang['wog_etc_email_send'] = '密碼已經寄到你註冊時的信箱';
$lang['wog_etc_email_subject'] = 'Online FF Battle - WOG 密碼回覆';
$lang['wog_etc_email_error'] = '無此email註冊過';
?>