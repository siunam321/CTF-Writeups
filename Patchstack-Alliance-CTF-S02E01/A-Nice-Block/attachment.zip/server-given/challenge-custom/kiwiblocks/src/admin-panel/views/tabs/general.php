<div class="kiwi_panel_tab">

    <header>
        <h3>Getting Started</h3>
    </header>

    <div>

        <ul class="kiwi_tabs">

            <li>
                <a href="#">What is Gutenberg?</a>
                <div class="kiwi_tabs-content">

                    <p>
                        Gutenberg is the new Wordpress Editor.
                    </p>

                    <img src="<?php echo esc_url(KIWIBLOCKS_URL); ?>/src/admin-panel/img/gutenberg.png" alt="">

                </div>
            </li>

            <li>
                <a href="#">What are Blocks?</a>
                <div class="kiwi_tabs-content">
                    <p>
                        Anything is a gutenberg block.
                    </p>

                </div>

            </li>

            <li>
                <a href="#">How to Add Block?</a>

                <div class="kiwi_tabs-content">

                    <p>
                        Create a new post by going to Posts > Add New.
                    </p>
                    <img src="<?php echo esc_url(KIWIBLOCKS_URL); ?>/src/admin-panel/img/adding-new-post.png" alt="">

                    <br>
                    <p>
                        Scroll down to "Kiwiblocks" section and select a block.
                    </p>

                </div>
            </li>


            <li>
                <a href="#">Block Settings</a>

                <div class="kiwi_tabs-content">
                    <p>
                        Find the block settings.
                    </p>

                </div>
            </li>

        </ul>

    </div>

</div>
