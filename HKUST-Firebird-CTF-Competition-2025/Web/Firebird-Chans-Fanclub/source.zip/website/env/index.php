<?php
session_start();
date_default_timezone_set("Asia/Hong_Kong");
error_reporting(0);

$notice = '';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] === false) {
    session_destroy();
    header("Location: /login.php");
    die();
}

if (isset($_GET['login']) && $_GET['login'] === 'true') {
    $notice = '
    <section class="message is-success">
        <div class="message-header">
            <p>Success</p>
        </div>
        <div class="message-body">
            You are logged in.
        </div>
    </section>
    ';
}

?>

<!DOCTYPE html>
<html>

<head>
    <style>
    <?php include 'style.css';
    ?>
    </style>
    <title>Home - Firebird Chan's Fanclub</title>
</head>

<body>
    <div class="container hero is-fullheight">

        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="/register.php">
                        Register
                    </a>
                    <a class="navbar-item" href="/login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="/play.php">
                        Play
                    </a>
                    <a class="navbar-item" href="/leaderboard.php">
                        Leaderboard
                    </a>
                    <a class="navbar-item" href="/flag.php">
                        Flag (For Members Only)
                    </a>
                    <a class="navbar-item" href="/logout.php">
                        Logout
                    </a>
                </div>

                <div class="navbar-end">
                    <div class="navbar-item">
                        <div class="buttons">
                            <a class="button is-primary" href="https://www.youtube.com/watch?v=Gc5NIjuAmU4&list=PLuxqoToY7UciHpW1-lDtgThiW4UbbyQ4_">
                                Hi, <?php echo $_SESSION['username'];?>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </nav>

        <section class="section">
            <?php echo $notice ?>
            <section class="hero is-link">
                <div class="hero-body">
                    <div class="container">
                        <h1 class="title">Firebird Chan's Fanclub</h1>
                        <h2 class="subtitle">Answer 5 Questions correctly to join the Firebird Chan Fanclub! (paying vow 10BTC may or
                            may not also work)</h2>
                    </div>
                </div>
            </section>
        </section>

        <h3 class="title is-3">Home</h3>
        <p class="subtitle">yeah there is nothing here, go play the quiz :(</p>

        <footer class="has-text-centered mt-auto pt-5 pb-5">
            <p>Styled with <a href="https://bulma.io/">Bulma</a>. </p>
        </footer>

    </div>

</body>

</html>