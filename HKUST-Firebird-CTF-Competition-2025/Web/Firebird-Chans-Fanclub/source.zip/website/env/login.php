<?php
include 'db_connection.php';
session_start();
date_default_timezone_set("Asia/Hong_Kong");
error_reporting(0);

$notice = '';

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: /index.php");
    die();
}

if (isset($_GET['register']) && $_GET['register'] === 'true') {
    $notice = '
    <section class="message is-success">
        <div class="message-header">
            <p>Success</p>
        </div>
        <div class="message-body">
            Your account has been created.
        </div>
    </section>
    ';
}

if (isset($_GET['logout']) && $_GET['logout'] === 'true') {
    $notice = '
    <section class="message is-success">
        <div class="message-header">
            <p>Success</p>
        </div>
        <div class="message-body">
            You have successfully logged out.
        </div>
    </section>
    ';
}

if (isset($_POST['username']) && isset($_POST['password']) && !empty($_POST['username']) && !empty($_POST['password'])) {
    $conn = OpenCon();
    $stmt = $conn->prepare("SELECT * FROM users WHERE Username = ?;");
    $stmt->bind_param("s", $_POST['username']);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_array(MYSQLI_NUM);
    if ((!empty($row)) && (count($row) === 4) && (password_verify($_POST['password'], $row[2]))) {
        $_SESSION["username"] = htmlspecialchars($row[1]);
        $_SESSION["loggedin"] = true;
        $_SESSION["role"] = $row[3];
        $_SESSION["correctNum"] = 0;
        $_SESSION["questionNum"] = 0;
        CloseCon($conn);
        header("Location: /index.php?login=true");
        die();
    } else {
        CloseCon($conn);
        $notice = '
        <section class="message is-danger">
            <div class="message-header">
                <p>Error</p>
            </div>
            <div class="message-body">
                Incorrect username or password.
            </div>
        </section>
        ';
    }
} else {
    if (!isset($_POST['username']) && !isset($_POST['password'])) {
        ;
    } else {
        $notice = '
        <section class="message is-danger">
            <div class="message-header">
                <p>Error</p>
            </div>
            <div class="message-body">
                Please input username and password.
            </div>
        </section>
        ';
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <style>
    <?php include 'style.css';
    ?>
    </style>
    <title>Home - Firebird Chan's Fanclub</title>
</head>

<body>
    <div class="container hero is-fullheight">

        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div id="navbar" class="navbar-menu">
                <div class="navbar-start">
                    <a class="navbar-item" href="/index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="/register.php">
                        Register
                    </a>
                    <a class="navbar-item" href="/login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="/play.php">
                        Play
                    </a>
                    <a class="navbar-item" href="/leaderboard.php">
                        Leaderboard
                    </a>
                    <a class="navbar-item" href="/flag.php">
                        Flag (For Members Only)
                    </a>
                    <a class="navbar-item" href="/logout.php">
                        Logout
                    </a>
                </div>
            </div>
        </nav>

        </article>

        <section class="section">
            <?php echo $notice ?>
            <section class="hero is-link">
                <div class="hero-body">
                    <div class="container">
                        <h1 class="title">Firebird Chan's Fanclub</h1>
                        <h2 class="subtitle">Answer 5 Questions correctly to join the Firebird Chan Fanclub! (paying vow
                            10BTC may or may not also work)</h2>
                    </div>
                </div>
            </section>
        </section>

        <h3 class="title is-3">Login</h3>

        <form action="/login.php" method="POST">
            <div class="field">
                <label class="label">Username</label>

                <div class="control">
                    <input class="input" type="text" placeholder="Username" name="username" />
                </div>

                <label class="label">Password</label>

                <div class="control">
                    <input class="input" type="text" placeholder="Password" name="password" />
                </div>
            </div>

            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-link" type="submit">Go</button>
                </div>
            </div>
        </form>

        <footer class="has-text-centered mt-auto pt-5 pb-5">
            <p>Styled with <a href="https://bulma.io/">Bulma</a>. </p>
        </footer>

    </div>

</body>

</html>